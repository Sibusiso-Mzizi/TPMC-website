import { createFileRoute, Link } from '@tanstack/react-router'

export const Route = createFileRoute('/packages')({
  component: PackagesPage,
})

const packages = [
  {
    id: 'start-up',
    name: 'Start-Up',
    badge: null,
    tagline: 'The essentials to get you legally registered and ready.',
    delivery: '5–7 business days',
    features: [
      'Company registration (CIPC)',
      'Income tax number',
      'SARS Tax Pin',
      'Share certificate',
      'Business profile (1-page PDF)',
    ],
    cta: 'Get Started',
  },
  {
    id: 'tender',
    name: 'Tender',
    badge: 'Popular',
    tagline: 'Everything you need to apply for tenders and contracts.',
    delivery: '7–10 business days',
    features: [
      'Company registration (CIPC)',
      'Income tax number & SARS Tax Pin',
      'Share certificate',
      'B-BBEE certificate',
      'CSD registration',
      'Business profile (professional)',
      'Logo design',
    ],
    cta: 'Get Started',
  },
  {
    id: 'pro',
    name: 'Pro',
    badge: null,
    tagline: 'A complete launch with digital presence included.',
    delivery: '10–14 business days',
    features: [
      'Everything in Tender package',
      'Social media account setup (2 platforms)',
      'Branded launch posts',
      '1-page starter website',
      'Content strategy document',
      'Email address setup',
    ],
    cta: 'Get Started',
  },
  {
    id: 'ultimate',
    name: 'Ultimate Launch',
    badge: 'Best Value',
    tagline: 'The complete package — registration, digital, and strategy.',
    delivery: '14–21 business days',
    features: [
      'Everything in Pro package',
      'Social media setup (Facebook, Instagram, LinkedIn, TikTok)',
      'Multi-page professional website',
      'Business consulting session (1hr)',
      'Growth strategy document',
      'Market research overview',
      '1 month post-launch support',
    ],
    cta: 'Get Started',
  },
]

const addons = [
  { name: 'Additional social media platform setup', note: 'Per platform' },
  { name: 'Poster / flyer design', note: 'Per design' },
  { name: 'Monthly social media management', note: 'Ongoing plan' },
  { name: 'Website upgrade (extra pages)', note: 'Per page' },
  { name: 'Monthly website maintenance', note: 'Ongoing plan' },
  { name: 'Business consulting session', note: 'Per session' },
  { name: 'Market research report', note: 'Custom scope' },
  { name: 'Rebranding package', note: 'Custom quote' },
  { name: '3-month Business Revamp Plan', note: 'Custom quote' },
]

function PackagesPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#1B2E4B] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-[#5BA4CF] font-semibold text-sm uppercase tracking-widest mb-3">Packages</p>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 max-w-2xl">
            Business Launch Packages
          </h1>
          <p className="text-white/60 text-lg max-w-xl">
            Four structured bundles to take you from zero to fully operational. All pricing is custom — book a consultation to get your quote.
          </p>
        </div>
      </section>

      {/* Packages Grid */}
      <section className="py-16 bg-[#F4F6F9]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            {packages.map((pkg) => (
              <div
                key={pkg.id}
                className={`rounded-2xl flex flex-col overflow-hidden shadow-sm hover:shadow-xl transition-shadow ${
                  pkg.badge === 'Best Value'
                    ? 'bg-[#1B2E4B] text-white ring-2 ring-[#3A7D44]'
                    : 'bg-white text-[#1A1A2E]'
                }`}
              >
                {/* Header */}
                <div className={`p-6 pb-4 ${pkg.badge === 'Best Value' ? 'bg-[#142238]' : 'bg-[#1B2E4B] text-white'}`}>
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-xl font-extrabold">{pkg.name}</h3>
                    {pkg.badge && (
                      <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                        pkg.badge === 'Best Value'
                          ? 'bg-[#3A7D44] text-white'
                          : 'bg-[#5BA4CF] text-white'
                      }`}>
                        {pkg.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-white/70 text-sm leading-relaxed">{pkg.tagline}</p>
                  <div className="mt-3 flex items-center gap-2 text-xs">
                    <svg className="w-3.5 h-3.5 text-[#5BA4CF]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-white/60">Delivery: {pkg.delivery}</span>
                  </div>
                </div>

                {/* Features */}
                <div className={`p-6 flex-1 ${pkg.badge === 'Best Value' ? '' : ''}`}>
                  <p className={`text-xs font-bold uppercase tracking-wider mb-4 ${
                    pkg.badge === 'Best Value' ? 'text-[#5BA4CF]' : 'text-[#3A7D44]'
                  }`}>What's included</p>
                  <ul className="space-y-3">
                    {pkg.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3">
                        <div className="w-4.5 h-4.5 rounded-full bg-[#3A7D44] flex items-center justify-center shrink-0 mt-0.5">
                          <svg className="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                        <span className={`text-sm ${pkg.badge === 'Best Value' ? 'text-white/80' : 'text-gray-600'}`}>
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA */}
                <div className="p-6 pt-0">
                  <Link
                    to="/contact"
                    className={`block text-center font-semibold py-3 rounded-lg transition-colors text-sm ${
                      pkg.badge === 'Best Value'
                        ? 'bg-[#3A7D44] hover:bg-[#2e6235] text-white'
                        : 'bg-[#1B2E4B] hover:bg-[#142238] text-white'
                    }`}
                  >
                    {pkg.cta} — Get a Quote
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <p className="text-center text-gray-500 text-sm mt-8">
            All packages require a free consultation to finalise scope and pricing. No hidden costs.
          </p>
        </div>
      </section>

      {/* Add-ons */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <p className="text-[#3A7D44] font-semibold text-sm uppercase tracking-widest mb-2">Add-Ons</p>
            <h2 className="text-3xl font-extrabold text-[#1B2E4B]">Enhance Any Package</h2>
            <p className="text-gray-500 mt-2 max-w-md mx-auto text-sm">
              Bolt on extra services to any package based on your business needs. All add-ons are priced on consultation.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
            {addons.map((addon) => (
              <div key={addon.name} className="flex items-center gap-4 p-4 rounded-xl border border-gray-100 hover:border-[#5BA4CF]/40 hover:bg-[#F4F6F9] transition-all">
                <div className="w-8 h-8 rounded-full bg-[#d6eaf8] flex items-center justify-center shrink-0">
                  <svg className="w-4 h-4 text-[#1B2E4B]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                </div>
                <div>
                  <p className="font-semibold text-[#1B2E4B] text-sm">{addon.name}</p>
                  <p className="text-gray-400 text-xs">{addon.note}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ strip */}
      <section className="py-12 bg-[#1B2E4B] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-extrabold mb-3">All pricing is done through consultation</h2>
          <p className="text-white/60 max-w-lg mx-auto mb-7 text-sm">
            We don't believe in one-size-fits-all pricing. Every quote is tailored to your specific needs, stage, and goals. Book a free consultation — no commitment required.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 bg-[#3A7D44] hover:bg-[#2e6235] text-white font-semibold px-8 py-3.5 rounded-lg transition-colors"
          >
            Book Your Free Consultation
          </Link>
        </div>
      </section>
    </>
  )
}
