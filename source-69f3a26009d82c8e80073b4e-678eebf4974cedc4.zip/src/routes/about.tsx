import { createFileRoute, Link } from '@tanstack/react-router'

export const Route = createFileRoute('/about')({
  component: AboutPage,
})

const values = [
  { icon: '⭐', title: 'Quality First', desc: 'We never cut corners. Every deliverable meets the standard your business deserves.' },
  { icon: '⚡', title: '2-Hour Response', desc: "You always hear back within two hours. That's not a goal — it's a standard we hold ourselves to." },
  { icon: '📊', title: 'Data-Driven', desc: 'Every recommendation is backed by real insights. No guesswork, no gut feelings alone.' },
  { icon: '🎯', title: 'Radical Accountability', desc: 'We own our work. If something needs fixing, we fix it — no excuses.' },
  { icon: '🤝', title: 'Every Client Valued', desc: 'Whether you have R500 or R50,000, you receive the same level of care and attention.' },
]

const process = [
  { step: '01', label: 'Define', desc: 'We start by deeply understanding your challenge, goals, and the context of your business. No assumptions.' },
  { step: '02', label: 'Collect', desc: 'We gather data — financial, operational, customer, market. The full picture before we prescribe anything.' },
  { step: '03', label: 'Analyse', desc: "We identify where the inefficiencies are, what's working, and where the biggest opportunities lie." },
  { step: '04', label: 'Develop', desc: 'We build a tailored solution together with you — not a template, but a strategy designed for your specific situation.' },
  { step: '05', label: 'Implement', desc: 'We help you execute the plan with precision, tracking progress and adjusting as needed.' },
  { step: '06', label: 'Optimise', desc: 'We review results, measure impact, refine the approach, and keep improving — continuously.' },
]

const reasons = [
  { title: 'We speak your language', desc: "We're built for young entrepreneurs. No corporate jargon, no one-size-fits-all solutions." },
  { title: 'Lean Six Sigma methodology', desc: 'A proven framework that eliminates waste and builds measurable, lasting results.' },
  { title: 'Human-centred approach', desc: 'We listen before we act. Your context shapes everything we build.' },
  { title: 'Ongoing support', desc: "We're not once-off advisors. We stay with you through implementation and beyond." },
  { title: 'Affordable and accessible', desc: 'Pricing that makes sense for students and early-stage startups — without compromising quality.' },
  { title: 'South African focus', desc: "We understand the local business environment, regulations, and market realities." },
]

function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#1B2E4B] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-[#5BA4CF] font-semibold text-sm uppercase tracking-widest mb-3">About Us</p>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 max-w-2xl">
            Built to Help the Next Generation Win
          </h1>
          <p className="text-white/60 text-lg max-w-xl">
            TP Mobility & Consulting exists because building a business as a young South African is hard. We're here to make it structured, supported, and sustainable.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-[#3A7D44] font-semibold text-sm uppercase tracking-widest mb-3">Our Story</p>
              <h2 className="text-3xl md:text-4xl font-extrabold text-[#1B2E4B] mb-5">
                Structured Support for Unstructured Beginnings
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  Too many young entrepreneurs in South Africa start with great ideas but no structure. They launch without registering, grow without a strategy, and burn out before they reach their potential. TP Mobility & Consulting was founded to change that.
                </p>
                <p>
                  We combine the rigour of Lean Six Sigma methodology with a genuinely human-centred approach — listening first, building second. We don't just hand you a document and disappear. We walk the journey with you.
                </p>
                <p>
                  From high school entrepreneurs running their first hustle to university students building companies and small businesses trying to scale, we've designed every service to meet you where you are and help you get where you're going.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-4">
              <div className="bg-[#1B2E4B] text-white rounded-2xl p-7">
                <p className="text-[#5BA4CF] font-bold text-xs uppercase tracking-wider mb-3">Mission</p>
                <p className="text-white/80 leading-relaxed">
                  To help startups and student entrepreneurs build sustainable, structured businesses through data-driven strategy, continuous improvement, and human-centred consulting.
                </p>
              </div>
              <div className="bg-[#3A7D44] text-white rounded-2xl p-7">
                <p className="text-white/70 font-bold text-xs uppercase tracking-wider mb-3">Vision</p>
                <p className="text-white/90 leading-relaxed">
                  To become Africa's leading consulting partner for early-stage entrepreneurs — turning ideas into structured, scalable businesses that last 10–20 years.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16 bg-[#F4F6F9]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-[#3A7D44] font-semibold text-sm uppercase tracking-widest mb-2">Core Values</p>
            <h2 className="text-3xl md:text-4xl font-extrabold text-[#1B2E4B]">What We Stand For</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
            {values.map((v) => (
              <div key={v.title} className="bg-white rounded-2xl p-6 text-center shadow-sm hover:shadow-md transition-shadow">
                <div className="text-3xl mb-3">{v.icon}</div>
                <h3 className="font-bold text-[#1B2E4B] mb-2 text-sm">{v.title}</h3>
                <p className="text-gray-500 text-xs leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lean Six Sigma */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-4">
            <p className="text-[#3A7D44] font-semibold text-sm uppercase tracking-widest mb-2">Our Methodology</p>
            <h2 className="text-3xl md:text-4xl font-extrabold text-[#1B2E4B]">Lean Six Sigma for Startups</h2>
            <p className="text-gray-500 mt-3 max-w-2xl mx-auto leading-relaxed">
              Lean Six Sigma is a data-driven methodology used by the world's most efficient organisations to eliminate waste, reduce variation, and improve outcomes. We apply these same principles — adapted for the startup environment — to help early-stage businesses build right from day one.
            </p>
          </div>
          <div className="mt-12">
            <h3 className="text-center font-bold text-[#1B2E4B] text-xl mb-8">Our Six-Phase Process</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {process.map((p) => (
                <div key={p.step} className="border border-gray-100 rounded-2xl p-6 hover:border-[#5BA4CF]/40 hover:shadow-md transition-all">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="w-9 h-9 rounded-full bg-[#1B2E4B] text-[#5BA4CF] font-bold text-sm flex items-center justify-center shrink-0">
                      {p.step}
                    </span>
                    <h4 className="font-bold text-[#1B2E4B] text-lg">{p.label}</h4>
                  </div>
                  <p className="text-gray-500 text-sm leading-relaxed">{p.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-[#1B2E4B] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-[#5BA4CF] font-semibold text-sm uppercase tracking-widest mb-2">Why TP Mobility</p>
            <h2 className="text-3xl md:text-4xl font-extrabold">Six Reasons to Choose Us</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {reasons.map((r) => (
              <div key={r.title} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-colors">
                <div className="w-8 h-8 rounded-full bg-[#3A7D44]/30 border border-[#3A7D44] flex items-center justify-center mb-4">
                  <svg className="w-4 h-4 text-[#5BA4CF]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="font-bold text-white mb-2">{r.title}</h3>
                <p className="text-white/60 text-sm leading-relaxed">{r.desc}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 bg-[#3A7D44] hover:bg-[#2e6235] text-white font-semibold px-8 py-3.5 rounded-lg transition-colors"
            >
              Book a Free Consultation
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}
