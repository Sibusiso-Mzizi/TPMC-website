import { HeadContent, Scripts, createRootRoute, Outlet } from '@tanstack/react-router'
import { Header } from '@/components/Header'
import { Footer } from '@/components/Footer'

import '../styles.css'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'TP Mobility & Consulting — Optimizing Startups For Success' },
      { name: 'description', content: 'South African business consulting firm helping student entrepreneurs and early-stage startups build structured, scalable, and sustainable businesses.' },
    ],
    links: [
      { rel: 'icon', href: '/logo.jpeg' },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        <Header />
        <main>{children}</main>
        <Footer />
        <Scripts />
      </body>
    </html>
  )
}
