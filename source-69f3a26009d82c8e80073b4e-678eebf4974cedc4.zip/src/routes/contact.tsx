import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/contact')({
  component: ContactPage,
})

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([key, val]) => `${encodeURIComponent(key)}=${encodeURIComponent(val)}`)
    .join('&')
}

const businessStages = [
  'I have an idea (not started yet)',
  'High school entrepreneur',
  'University student startup',
  'Early-stage startup (0–1 year)',
  'Growing startup (1–3 years)',
  'Small business (3+ years)',
]

const serviceOptions = [
  'Business Launch & Registration',
  'Social Media Management',
  'Website Design',
  'Business Consulting',
  'Student & Startup Support Plans',
  'Packages / Bundle',
  "Not sure — I'd like guidance",
]

function ContactPage() {
  const [fields, setFields] = useState({
    name: '',
    email: '',
    whatsapp: '',
    'business-stage': '',
    'service-interest': '',
    message: '',
  })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => setFields({ ...fields, [e.target.name]: e.target.value })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      await fetch('/contact-form.html', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encode({ 'form-name': 'contact', ...fields }),
      })
      setSubmitted(true)
    } catch {
      setError('Something went wrong. Please try again or reach out via WhatsApp.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {/* Hero */}
      <section className="bg-[#1B2E4B] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-[#5BA4CF] font-semibold text-sm uppercase tracking-widest mb-3">Contact Us</p>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 max-w-2xl">
            Let's Talk About Your Business
          </h1>
          <p className="text-white/60 text-lg max-w-xl">
            No commitment. No pressure. Just a real conversation about where you are and where you want to go.
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Contact Details */}
            <div>
              <h2 className="text-xl font-extrabold text-[#1B2E4B] mb-6">Get in Touch</h2>
              <div className="space-y-5">
                <a
                  href="https://wa.me/27685347269"
                  className="flex items-start gap-4 p-4 rounded-xl border border-gray-100 hover:border-[#3A7D44]/40 hover:bg-[#F4F6F9] transition-all group"
                >
                  <div className="w-10 h-10 rounded-xl bg-[#3A7D44]/10 text-[#3A7D44] flex items-center justify-center shrink-0 group-hover:bg-[#3A7D44] group-hover:text-white transition-colors">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium uppercase tracking-wider mb-0.5">WhatsApp</p>
                    <p className="font-semibold text-[#1B2E4B]">+27 68 534 7269</p>
                    <p className="text-xs text-gray-500">We respond within 2 hours</p>
                  </div>
                </a>

                <a
                  href="mailto:sales@buildwithtp.com"
                  className="flex items-start gap-4 p-4 rounded-xl border border-gray-100 hover:border-[#3A7D44]/40 hover:bg-[#F4F6F9] transition-all group"
                >
                  <div className="w-10 h-10 rounded-xl bg-[#5BA4CF]/10 text-[#5BA4CF] flex items-center justify-center shrink-0 group-hover:bg-[#5BA4CF] group-hover:text-white transition-colors">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium uppercase tracking-wider mb-0.5">Email</p>
                    <p className="font-semibold text-[#1B2E4B]">sales@buildwithtp.com</p>
                    <p className="text-xs text-gray-500">For detailed enquiries</p>
                  </div>
                </a>

                <div className="flex items-start gap-4 p-4 rounded-xl border border-gray-100 bg-[#F4F6F9]">
                  <div className="w-10 h-10 rounded-xl bg-[#1B2E4B]/10 text-[#1B2E4B] flex items-center justify-center shrink-0">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium uppercase tracking-wider mb-0.5">Website</p>
                    <p className="font-semibold text-[#1B2E4B]">buildwithtp.com</p>
                    <p className="text-xs text-gray-500">South Africa</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-5 bg-[#1B2E4B] rounded-2xl text-white">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2 h-2 rounded-full bg-[#3A7D44] animate-pulse" />
                  <p className="font-semibold text-sm">2-Hour Response Guarantee</p>
                </div>
                <p className="text-white/60 text-sm leading-relaxed">
                  We commit to responding to every enquiry within 2 hours during business hours. Your time matters.
                </p>
              </div>
            </div>

            {/* Form */}
            <div className="lg:col-span-2">
              <h2 className="text-xl font-extrabold text-[#1B2E4B] mb-6">Send an Enquiry</h2>

              {submitted ? (
                <div className="bg-[#3A7D44]/10 border border-[#3A7D44]/30 rounded-2xl p-10 text-center">
                  <div className="w-16 h-16 rounded-full bg-[#3A7D44] text-white flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-extrabold text-[#1B2E4B] mb-2">Enquiry Received!</h3>
                  <p className="text-gray-600 max-w-sm mx-auto">
                    Thanks for reaching out. We'll be in touch within 2 hours. In the meantime, feel free to WhatsApp us directly.
                  </p>
                  <a
                    href="https://wa.me/27685347269"
                    className="inline-flex items-center gap-2 mt-6 bg-[#3A7D44] text-white font-semibold px-6 py-2.5 rounded-lg hover:bg-[#2e6235] transition-colors text-sm"
                  >
                    Chat on WhatsApp
                  </a>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <input type="hidden" name="form-name" value="contact" />
                  {/* Honeypot */}
                  <div className="hidden">
                    <input name="bot-field" tabIndex={-1} autoComplete="off" />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label htmlFor="name" className="block text-sm font-semibold text-[#1B2E4B] mb-1.5">
                        Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="name"
                        type="text"
                        name="name"
                        required
                        value={fields.name}
                        onChange={handleChange}
                        placeholder="Your full name"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 text-[#1A1A2E] placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#5BA4CF] focus:border-transparent transition"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-semibold text-[#1B2E4B] mb-1.5">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="email"
                        type="email"
                        name="email"
                        required
                        value={fields.email}
                        onChange={handleChange}
                        placeholder="you@example.com"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 text-[#1A1A2E] placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#5BA4CF] focus:border-transparent transition"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="whatsapp" className="block text-sm font-semibold text-[#1B2E4B] mb-1.5">
                      WhatsApp Number
                    </label>
                    <input
                      id="whatsapp"
                      type="tel"
                      name="whatsapp"
                      value={fields.whatsapp}
                      onChange={handleChange}
                      placeholder="+27 00 000 0000"
                      className="w-full px-4 py-3 rounded-lg border border-gray-200 text-[#1A1A2E] placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#5BA4CF] focus:border-transparent transition"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label htmlFor="business-stage" className="block text-sm font-semibold text-[#1B2E4B] mb-1.5">
                        Business Stage <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="business-stage"
                        name="business-stage"
                        required
                        value={fields['business-stage']}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 text-[#1A1A2E] text-sm focus:outline-none focus:ring-2 focus:ring-[#5BA4CF] focus:border-transparent transition bg-white"
                      >
                        <option value="">Select your stage</option>
                        {businessStages.map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label htmlFor="service-interest" className="block text-sm font-semibold text-[#1B2E4B] mb-1.5">
                        Service Interest <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="service-interest"
                        name="service-interest"
                        required
                        value={fields['service-interest']}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 text-[#1A1A2E] text-sm focus:outline-none focus:ring-2 focus:ring-[#5BA4CF] focus:border-transparent transition bg-white"
                      >
                        <option value="">Select a service</option>
                        {serviceOptions.map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold text-[#1B2E4B] mb-1.5">
                      Message <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={5}
                      value={fields.message}
                      onChange={handleChange}
                      placeholder="Tell us about your business idea, your current challenges, or what you're looking to achieve..."
                      className="w-full px-4 py-3 rounded-lg border border-gray-200 text-[#1A1A2E] placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#5BA4CF] focus:border-transparent transition resize-none"
                    />
                  </div>

                  {error && (
                    <div className="text-red-600 text-sm bg-red-50 border border-red-100 rounded-lg p-3">
                      {error}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#1B2E4B] hover:bg-[#142238] disabled:opacity-60 text-white font-semibold py-3.5 rounded-lg transition-colors text-sm flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <>
                        <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                        </svg>
                        Sending...
                      </>
                    ) : (
                      <>
                        Send Enquiry
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                        </svg>
                      </>
                    )}
                  </button>
                  <p className="text-center text-xs text-gray-400">
                    We'll respond within 2 hours. No spam, ever.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
