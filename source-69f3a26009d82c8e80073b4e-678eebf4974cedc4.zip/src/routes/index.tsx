import { createFileRoute, Link } from '@tanstack/react-router'

export const Route = createFileRoute('/')({
  component: HomePage,
})

const stats = [
  { value: '2hrs', label: 'Response guarantee' },
  { value: '0–3', label: 'Years startup focus' },
  { value: '5+', label: 'Service categories' },
  { value: '100%', label: 'Data-driven approach' },
]

const services = [
  {
    icon: (
      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
    ),
    title: 'Business Launch & Registration',
    desc: 'Company registration, B-BBEE certification, SARS setup, business profile, logo, social media, and website — everything to go from idea to official.',
  },
  {
    icon: (
      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
      </svg>
    ),
    title: 'Social Media Management',
    desc: 'Page setup across Facebook, Instagram, LinkedIn & TikTok, plus monthly management with content creation, community engagement, and paid ads.',
  },
  {
    icon: (
      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    ),
    title: 'Website Design',
    desc: 'Clean, mobile-responsive, SEO-ready websites. From basic 1–3 page sites to full e-commerce stores with payment gateways.',
  },
  {
    icon: (
      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>
    ),
    title: 'Business Consulting',
    desc: 'Personalised strategy sessions covering idea review, growth planning, operations, marketing, and business structure using Lean Six Sigma methodology.',
  },
  {
    icon: (
      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
      </svg>
    ),
    title: 'Student & Startup Support',
    desc: 'Affordable plans designed for young entrepreneurs — digital setup, social media training, market research, poster design, and 3-month business revamp.',
  },
]

const audiences = [
  { emoji: '🎓', title: 'High School Entrepreneurs', desc: 'Turning school-level hustle into registered, structured businesses ready to grow.' },
  { emoji: '🏫', title: 'University Students', desc: 'Building your startup while studying — with the systems and strategy to make it last.' },
  { emoji: '🚀', title: 'Early-Stage Startups', desc: '0–3 years in business and ready to scale? We bring the structure that makes growth sustainable.' },
  { emoji: '📈', title: 'Small Businesses', desc: 'Struggling with growth, structure, or customer retention? We diagnose and fix the root causes.' },
]

const process = [
  { step: '01', label: 'Define', desc: 'Understand your challenge and goals' },
  { step: '02', label: 'Collect', desc: 'Gather data and business insights' },
  { step: '03', label: 'Analyse', desc: 'Identify inefficiencies and opportunities' },
  { step: '04', label: 'Develop', desc: 'Build a tailored solution with you' },
  { step: '05', label: 'Implement', desc: 'Execute the plan with precision' },
  { step: '06', label: 'Optimise', desc: 'Review, refine, and keep improving' },
]

function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#1B2E4B] text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-10 right-10 w-64 h-64 rounded-full border-2 border-white" />
          <div className="absolute bottom-10 left-10 w-96 h-96 rounded-full border border-white" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-[#3A7D44]/20 border border-[#3A7D44]/40 text-[#5BA4CF] text-sm font-medium px-4 py-1.5 rounded-full mb-6">
              <span className="w-2 h-2 rounded-full bg-[#3A7D44] animate-pulse" />
              Optimizing Startups For Success
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold leading-tight mb-6">
              We Build <span className="text-[#5BA4CF]">Structured,</span>{' '}
              <span className="text-[#3A7D44]">Scalable</span> Businesses.
            </h1>
            <p className="text-lg md:text-xl text-white/70 leading-relaxed mb-8 max-w-2xl">
              From idea to lasting business — TP Mobility & Consulting helps student entrepreneurs and early-stage startups in South Africa build with clarity, data, and purpose.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/contact"
                className="inline-flex items-center justify-center gap-2 bg-[#3A7D44] hover:bg-[#2e6235] text-white font-semibold px-7 py-3.5 rounded-lg transition-colors text-base"
              >
                Book a Free Consultation
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </Link>
              <Link
                to="/services"
                className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold px-7 py-3.5 rounded-lg transition-colors text-base"
              >
                Explore Our Services
              </Link>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="bg-[#142238] border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {stats.map((s) => (
                <div key={s.label} className="text-center">
                  <div className="text-2xl font-extrabold text-[#5BA4CF]">{s.value}</div>
                  <div className="text-xs text-white/50 mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* What We Do */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <p className="text-[#3A7D44] font-semibold text-sm uppercase tracking-widest mb-2">What We Do</p>
            <h2 className="text-3xl md:text-4xl font-extrabold text-[#1B2E4B]">Five Ways We Grow Your Business</h2>
            <p className="text-gray-500 mt-3 max-w-xl mx-auto">No generic advice. Real strategy built around your specific situation, goals, and stage.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, i) => (
              <div
                key={service.title}
                className={`p-6 rounded-2xl border border-gray-100 hover:border-[#5BA4CF]/40 hover:shadow-lg transition-all group ${
                  i === 4 ? 'sm:col-span-2 lg:col-span-1' : ''
                }`}
              >
                <div className="w-13 h-13 rounded-xl bg-[#d6eaf8] text-[#1B2E4B] flex items-center justify-center mb-4 group-hover:bg-[#1B2E4B] group-hover:text-white transition-colors">
                  {service.icon}
                </div>
                <h3 className="font-bold text-[#1B2E4B] text-lg mb-2">{service.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{service.desc}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link
              to="/services"
              className="inline-flex items-center gap-2 text-[#3A7D44] font-semibold hover:underline"
            >
              View all services
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </Link>
          </div>
        </div>
      </section>

      {/* Who We Serve */}
      <section className="py-20 bg-[#F4F6F9]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <p className="text-[#3A7D44] font-semibold text-sm uppercase tracking-widest mb-2">Who We Serve</p>
            <h2 className="text-3xl md:text-4xl font-extrabold text-[#1B2E4B]">Built for the Next Generation</h2>
            <p className="text-gray-500 mt-3 max-w-xl mx-auto">Whether you're still in school or just launched, we speak your language and understand your journey.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {audiences.map((a) => (
              <div key={a.title} className="bg-white p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow text-center">
                <div className="text-4xl mb-4">{a.emoji}</div>
                <h3 className="font-bold text-[#1B2E4B] mb-2">{a.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{a.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="py-20 bg-[#1B2E4B] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <p className="text-[#5BA4CF] font-semibold text-sm uppercase tracking-widest mb-2">Our Method</p>
            <h2 className="text-3xl md:text-4xl font-extrabold">The Lean Six Sigma Process</h2>
            <p className="text-white/60 mt-3 max-w-xl mx-auto">
              We don't guess — we follow a proven six-phase framework that eliminates waste, identifies inefficiencies, and builds measurable results.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {process.map((p, i) => (
              <div key={p.step} className="relative text-center">
                {i < process.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-[calc(50%+2rem)] w-full h-px bg-[#3A7D44]/40" />
                )}
                <div className="w-16 h-16 rounded-full bg-[#3A7D44]/20 border border-[#3A7D44] flex items-center justify-center mx-auto mb-3">
                  <span className="text-[#5BA4CF] font-bold text-sm">{p.step}</span>
                </div>
                <h4 className="font-bold text-white mb-1">{p.label}</h4>
                <p className="text-white/50 text-xs leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Core Promise */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-[#3A7D44] font-semibold text-sm uppercase tracking-widest mb-2">Our Promise</p>
              <h2 className="text-3xl md:text-4xl font-extrabold text-[#1B2E4B] mb-6">We Build With You, Not Just For You</h2>
              <div className="space-y-5">
                {[
                  { title: 'Human-centred approach', desc: 'We listen before we act. Your context shapes every recommendation.' },
                  { title: 'Ongoing support', desc: 'Not once-off advice — we stay with you through implementation and beyond.' },
                  { title: 'Data-driven decisions', desc: 'Every strategy is backed by real data, not guesswork or assumptions.' },
                  { title: '2-hour response guarantee', desc: "When you reach out, we respond. Always — within two hours." },
                ].map((item) => (
                  <div key={item.title} className="flex gap-4">
                    <div className="w-6 h-6 rounded-full bg-[#3A7D44] flex items-center justify-center shrink-0 mt-0.5">
                      <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-semibold text-[#1B2E4B]">{item.title}</h4>
                      <p className="text-gray-500 text-sm mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-[#F4F6F9] rounded-3xl p-8">
              <div className="bg-[#1B2E4B] text-white rounded-2xl p-6 mb-4">
                <p className="text-[#5BA4CF] text-sm font-semibold mb-2">Mission</p>
                <p className="text-white/80 text-sm leading-relaxed">
                  To help startups and student entrepreneurs build sustainable, structured businesses through data-driven strategy, continuous improvement, and human-centred consulting.
                </p>
              </div>
              <div className="bg-[#3A7D44] text-white rounded-2xl p-6">
                <p className="text-white/70 text-sm font-semibold mb-2">Vision</p>
                <p className="text-white/90 text-sm leading-relaxed">
                  To become Africa's leading consulting partner for early-stage entrepreneurs — turning ideas into structured, scalable businesses that last 10–20 years.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-16 bg-[#3A7D44]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-extrabold text-white mb-4">
            Ready to Build Something That Lasts?
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-xl mx-auto">
            Book your free consultation today. No pressure, no obligation — just a real conversation about your business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="inline-flex items-center justify-center gap-2 bg-white text-[#3A7D44] font-bold px-8 py-3.5 rounded-lg hover:bg-gray-50 transition-colors text-base"
            >
              Book Free Consultation
            </Link>
            <Link
              to="/packages"
              className="inline-flex items-center justify-center gap-2 bg-white/15 border border-white/30 text-white font-semibold px-8 py-3.5 rounded-lg hover:bg-white/25 transition-colors text-base"
            >
              View Packages
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}
