import { createFileRoute, Link } from '@tanstack/react-router'

export const Route = createFileRoute('/services')({
  component: ServicesPage,
})

const services = [
  {
    id: 'business-launch',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
    ),
    title: 'Business Launch & Registration',
    tagline: 'From idea to official — everything you need to start legally and professionally.',
    description:
      "Starting a business means more than having a great idea. It means having the right structure, documentation, and digital presence from day one. We handle all the admin so you can focus on building.",
    features: [
      'Company registration with CIPC',
      'B-BBEE certificate',
      'Share certificate',
      'Income tax number & SARS Tax Pin',
      'CSD registration',
      'Professional business profile',
      'Logo design',
      'Social media account setup',
      '1-page starter website',
    ],
    note: 'Available as standalone services or bundled into our Launch Packages.',
  },
  {
    id: 'social-media',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
      </svg>
    ),
    title: 'Social Media Management',
    tagline: 'A professional presence on every platform that matters.',
    description:
      'Your social media is often the first impression of your business. We set it up right and keep it growing — with content that connects, community that engages, and ads that convert.',
    features: [
      'Once-off page setup: Facebook, Instagram, LinkedIn, TikTok',
      'Profile design with branded visuals',
      'Branded launch posts & content strategy',
      'Monthly content creation & scheduling',
      'Community engagement & comment management',
      'Paid ads setup and management',
      'Bi-monthly performance reporting',
    ],
    note: 'Once-off setup or ongoing monthly management plans — choose what suits your stage.',
  },
  {
    id: 'website-design',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    ),
    title: 'Website Design',
    tagline: 'Clean, credible, and built to work on any device.',
    description:
      'Your website is your 24/7 salesperson. We design websites that are mobile-responsive, SEO-optimised, and built to convert visitors into enquiries — without the unnecessary complexity.',
    features: [
      'Basic: 1–3 pages (ideal for new businesses)',
      'Professional Startup: 4–6 pages with blog',
      'E-Commerce: online store with payment gateway',
      'Custom solutions for complex needs',
      'Mobile-first, responsive design',
      'SEO-ready structure and metadata',
      'Monthly maintenance plans available',
    ],
    note: 'All websites are built with your brand in mind. No templates that look like everyone else.',
  },
  {
    id: 'consulting',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>
    ),
    title: 'Business Consulting',
    tagline: 'Real strategy. No fluff. Built around your specific situation.',
    description:
      'We apply Lean Six Sigma methodology to identify exactly where your business is losing time, money, or momentum — then we build a structured plan to fix it. Personalised for students, startups, and growing small businesses.',
    features: [
      'Idea review and validation',
      'Growth strategy development',
      'Operations analysis and optimisation',
      'Marketing strategy and positioning',
      'Business structure recommendations',
      'Lean Six Sigma gap analysis',
      'Ongoing support sessions',
    ],
    note: 'Available for students, early-stage startups (0–3 years), and small businesses.',
  },
  {
    id: 'student-support',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
      </svg>
    ),
    title: 'Student & Startup Support Plans',
    tagline: 'Affordable, ongoing support designed for young entrepreneurs.',
    description:
      "We know budgets are tight when you're starting out. These plans give you the tools, training, and support you need without the enterprise price tag.",
    features: [
      'Student Digital Plan (affordable entry)',
      'Post-sales support package',
      'Social media training sessions',
      'Poster & marketing material design',
      'Market research assistance',
      'Rebranding packages',
      '3-month Business Revamp Plan',
    ],
    note: 'Designed for high school entrepreneurs, university students, and first-year startups.',
  },
]

function ServicesPage() {
  return (
    <>
      {/* Hero */}
      <section className="bg-[#1B2E4B] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-[#5BA4CF] font-semibold text-sm uppercase tracking-widest mb-3">Our Services</p>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 max-w-2xl">Everything Your Business Needs to Grow</h1>
          <p className="text-white/60 text-lg max-w-xl">
            Five focused service categories — each designed to address a specific stage of your entrepreneurial journey.
          </p>
        </div>
      </section>

      {/* Services */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-16">
            {services.map((service, index) => (
              <div
                key={service.id}
                id={service.id}
                className={`grid md:grid-cols-2 gap-10 items-start ${
                  index % 2 === 1 ? 'md:[&>div:first-child]:order-2' : ''
                }`}
              >
                {/* Content */}
                <div>
                  <div className="w-14 h-14 rounded-xl bg-[#d6eaf8] text-[#1B2E4B] flex items-center justify-center mb-5">
                    {service.icon}
                  </div>
                  <h2 className="text-2xl md:text-3xl font-extrabold text-[#1B2E4B] mb-2">{service.title}</h2>
                  <p className="text-[#3A7D44] font-semibold mb-4">{service.tagline}</p>
                  <p className="text-gray-600 leading-relaxed mb-6">{service.description}</p>
                  <Link
                    to="/contact"
                    className="inline-flex items-center gap-2 bg-[#1B2E4B] hover:bg-[#142238] text-white font-semibold px-6 py-3 rounded-lg transition-colors text-sm"
                  >
                    Get a Custom Quote
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </Link>
                </div>

                {/* Features */}
                <div className="bg-[#F4F6F9] rounded-2xl p-7">
                  <h3 className="font-bold text-[#1B2E4B] mb-5 text-sm uppercase tracking-wider">What's Included</h3>
                  <ul className="space-y-3">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3">
                        <div className="w-5 h-5 rounded-full bg-[#3A7D44] flex items-center justify-center shrink-0 mt-0.5">
                          <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  {service.note && (
                    <p className="mt-5 pt-4 border-t border-gray-200 text-xs text-gray-500 italic">{service.note}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-[#1B2E4B] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-extrabold mb-4">Not sure where to start?</h2>
          <p className="text-white/60 mb-8 max-w-md mx-auto">
            Book a free consultation and we'll help you figure out exactly what your business needs right now.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 bg-[#3A7D44] hover:bg-[#2e6235] text-white font-semibold px-8 py-3.5 rounded-lg transition-colors"
          >
            Book Free Consultation
          </Link>
        </div>
      </section>
    </>
  )
}
