import { useState } from 'react'
import { Link } from '@tanstack/react-router'

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/services', label: 'Services' },
  { to: '/about', label: 'About' },
  { to: '/packages', label: 'Packages' },
  { to: '/contact', label: 'Contact' },
]

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <header className="bg-[#1B2E4B] text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 hover:opacity-90 transition-opacity">
            <img src="/logo.jpeg" alt="TP Mobility & Consulting" className="h-10 w-10 rounded-md object-contain bg-white p-0.5" />
            <div>
              <div className="font-bold text-base leading-tight">TP Mobility</div>
              <div className="text-[#5BA4CF] text-xs font-medium leading-tight">& Consulting</div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {navLinks.map(({ to, label }) => (
              <Link
                key={to}
                to={to}
                className="text-sm font-medium text-white/80 hover:text-white transition-colors"
                activeProps={{ className: 'text-[#5BA4CF] font-semibold' }}
                activeOptions={{ exact: to === '/' }}
              >
                {label}
              </Link>
            ))}
          </nav>

          {/* CTA */}
          <div className="hidden md:block">
            <Link
              to="/contact"
              className="bg-[#3A7D44] hover:bg-[#2e6235] text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-colors"
            >
              Book Free Consultation
            </Link>
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden p-2 rounded-md text-white/80 hover:text-white"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {menuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-[#142238] border-t border-white/10 px-4 py-4">
          <nav className="flex flex-col gap-1">
            {navLinks.map(({ to, label }) => (
              <Link
                key={to}
                to={to}
                className="px-3 py-2.5 text-sm font-medium text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                activeProps={{ className: 'text-[#5BA4CF] bg-white/5 font-semibold' }}
                activeOptions={{ exact: to === '/' }}
                onClick={() => setMenuOpen(false)}
              >
                {label}
              </Link>
            ))}
            <Link
              to="/contact"
              className="mt-3 bg-[#3A7D44] hover:bg-[#2e6235] text-white text-sm font-semibold px-4 py-2.5 rounded-lg transition-colors text-center"
              onClick={() => setMenuOpen(false)}
            >
              Book Free Consultation
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
