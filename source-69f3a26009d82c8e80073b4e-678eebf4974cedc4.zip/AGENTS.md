# AGENTS.md — TP Mobility & Consulting Website

This file documents the project architecture for AI agents working on future sessions.

## Project Overview

A 5-page marketing website for TP Mobility & Consulting, a South African business consulting firm helping student entrepreneurs and early-stage startups build structured, scalable, and sustainable businesses. Built with TanStack Start and deployed on Netlify.

### Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | TanStack Start |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Tailwind CSS 4 (arbitrary value approach) |
| Forms | Netlify Forms |
| Language | TypeScript 5.7 (strict mode) |
| Deployment | Netlify |

## Directory Structure

```
src/
  components/
    Header.tsx        — Sticky navbar with logo, desktop nav, mobile hamburger
    Footer.tsx        — Footer with brand info, quick links, contact details
  routes/
    __root.tsx        — Root layout: mounts Header, <main>, Footer
    index.tsx         — Home page: hero, services grid, audiences, process, CTA
    services.tsx      — Services detail: 5 alternating content+features sections
    about.tsx         — About: story, values, Lean Six Sigma process, why us
    packages.tsx      — Packages: 4 launch bundles + add-ons grid
    contact.tsx       — Contact: Netlify Forms enquiry + contact detail cards
  styles.css          — Tailwind v4 import + Google Fonts import + base body styles
public/
  logo.jpeg           — Brand logo (moved from upload session assets)
  contact-form.html   — Static Netlify Forms skeleton (required for form detection at build time)
  favicon.ico
```

## Brand Colors

All colors are used as Tailwind arbitrary values — no custom config file needed.

| Hex | Role |
|-----|------|
| `#1B2E4B` | Primary navy — navbar, hero, headings, primary buttons, footer |
| `#142238` | Dark navy — hover states on navy elements |
| `#3A7D44` | Forest green — CTAs, checkmarks, accents, success states |
| `#2e6235` | Dark green — hover on green buttons |
| `#5BA4CF` | Sky blue — secondary accents, badges, active nav links |
| `#d6eaf8` | Light sky — icon backgrounds, subtle highlights |
| `#1A1A2E` | Dark charcoal — body text |
| `#F4F6F9` | Light gray — alternate section backgrounds |

## Key Architectural Decisions

### File-Based Routing
Routes map directly to files in `src/routes/`. The root layout in `__root.tsx` wraps all pages with Header and Footer — no per-page layout duplication.

### Netlify Forms (TanStack Start pattern)
SSR frameworks require a static HTML skeleton for Netlify to detect forms at build time:
- `public/contact-form.html` — hidden form with all field names (`name`, `email`, `whatsapp`, `business-stage`, `service-interest`, `message`)
- `src/routes/contact.tsx` — React form POSTing to `/contact-form.html` via `fetch` with `application/x-www-form-urlencoded`
- The hidden `<input name="form-name" value="contact">` is mandatory in the React form

### No Pricing Displayed
All service and package pages use "Get a Custom Quote" CTAs per business requirement. Pricing is never shown.

### No AI Features
Pure marketing site. No AI assistant or product catalog. Add with `netlify-ai-gateway` skill if needed.

## Coding Conventions

- Tailwind arbitrary color values throughout (`bg-[#1B2E4B]`) — no tailwind.config.js
- Icons are inline SVGs — no icon library runtime dependency
- TypeScript strict mode — all handlers and state are typed
- No comments unless non-obvious
- Route components: named `<Page>Page`, exported via `Route` object
- `Link` from `@tanstack/react-router` for all internal navigation

## Configuration Files

| File | Purpose |
|------|---------|
| `vite.config.ts` | TanStack Start, Netlify, Tailwind plugins |
| `tsconfig.json` | ES2022, strict, `@/*` alias for `src/*` |
| `netlify.toml` | Build command, publish dir (`dist/client`), dev port |

## Development

```bash
npm install
npm run dev    # http://localhost:3000
npm run build  # production build to dist/client/
```

Netlify Forms only works on deployed environments, not local dev.
