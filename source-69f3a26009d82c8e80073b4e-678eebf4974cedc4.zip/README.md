# TP Mobility & Consulting

**Optimizing Startups For Success** — South African business consulting firm helping student entrepreneurs and early-stage startups build structured, scalable, and sustainable businesses.

## About

This is the official website for [TP Mobility & Consulting](https://buildwithtp.com), a consulting firm that applies Lean Six Sigma methodology combined with a human-centred approach to help:

- High school entrepreneurs
- University student startups
- Early-stage startups (0–3 years)
- Small businesses struggling with growth or structure

## Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | [TanStack Start](https://tanstack.com/start) |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Tailwind CSS 4 |
| Forms | Netlify Forms |
| Deployment | Netlify |

## Pages

- **Home** (`/`) — Hero, services overview, who we serve, six-phase process, core promise
- **Services** (`/services`) — Five service categories in detail
- **About** (`/about`) — Company story, mission/vision, core values, Lean Six Sigma methodology
- **Packages** (`/packages`) — Four business launch packages + add-ons
- **Contact** (`/contact`) — Enquiry form (Netlify Forms) + contact details

## Running Locally

```bash
npm install
npm run dev
```

App runs at [http://localhost:3000](http://localhost:3000).

> **Note:** Netlify Forms does not work in local dev. Form submissions only work on deployed Netlify environments.

## Building for Production

```bash
npm run build
```

Output goes to `dist/client/`.

## Environment Variables

No environment variables required for the base site. If AI features are added in future, set one of: `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, or `GEMINI_API_KEY`.

## Contact

- WhatsApp: +27 68 534 7269
- Email: sales@buildwithtp.com
- Website: buildwithtp.com
